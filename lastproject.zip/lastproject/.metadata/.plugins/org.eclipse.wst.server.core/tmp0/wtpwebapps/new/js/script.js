function zipCheck(){
	url = "zipcheck.jsp?check=y";
	window.open(url,"post",
			"toolbar=no, width=350, height=300, top=200, left=300, status=yes, scrollbars=yes, menubar=no"); //우편물 post 얘기
}

function idCheck(){
	if(regForm.id.value === ""){
		alert("id를 입력하시오");
		regForm.id.focus();
	}else{
		url = "idcheck.jsp?id=" + regForm.id.value;
		window.open(url, "","width=300,height=150,left=150,top=150");
	}
}

function inputCheck(){
	if(regForm.id.value == ""){
		alert("id를 입력하세요");
		regForm.id.focus();
		return;
	}
	if(regForm.passwd.value !== regForm.repasswd.value){
		alert("비밀번호가 틀렸습니다");
		regForm.passwd.focus();
		return;
	}
	if(regForm.name.value == ""){
		alert("회원 이름 다시 입력하세요");
		regForm.name.focus();
		return;
	}
	
	
	if(regForm.job.value == "0"){
		alert("직업을 선택해주세요");
		regForm.job.focus();
		return;
	}
	
	document.regForm.submit();
		
}

	function memberUpdateOk(){
		document.updateForm.submit();
		
	}
	
	function memberUpdateCancel(){
		location.href="../guest/guest_index.jsp"
	}
	
	function memberDelete(){
		alert("회원 탈퇴");
	}
	
	function func1AdminLogin(){
		if(adminloginform.adminid.value == ""){
			alert("id를 입력하시오");
			adminloginform.adminid.focus();
			return;
		}
		if(adminloginform.adminpasswd.value == ""){
			alert("Password를 입력하시오");
			adminloginform.adminpasswd.focus();
			return;
	}
		adminloginform.submit();
	}
	function func1AdminHome(){
		location.href="../index.jsp";
	}
	
	function memUpdate(id){ 
		document.updateFrm.id.value = id;
		document.updateFrm.submit();
		}
	
	function memberUpdateAdmin(){
		document.updateFormAdmin.submit();
	}
	
	function memberUpdateCancelAdmin(){
		location.href ="membermanager.jsp";		
	}
	

	function productDetail_guest(no){
		document.detailFrm.no.value = no;
		document.detailFrm.submit();
	}
	
	function productDetail(no){
		document.detailForm.no.value = no;
		document.detailForm.submit();
	}
	
	function ProductUpdate(no) {
		if(confirm("정말 수정하시겠습니까?")){
		document.updateForm.no.value = no;
		document.updateForm.submit();
		}
		
	}
	

	function ProductDelete(no) {
	if (confirm("정말 삭제하시겠습니까?")) {
		document.delForm.no.value = no;
		document.delForm.submit();
	}
}
	

function cartUpdate(form){
		form.flag.value = "update";
		form.submit();
}

function cartDelete(form){
		form.flag.value = "del";
		form.submit();
}


function orderDetail(no){
	document.detailFrm.no.value = no;
	document.detailFrm.submit();
}

function orderUpdate(form){
	document.detailFrm.flag.value = "update";
	form.submit();
}

function orderDelete(form){
	document.detailFrm.flag.value = "delete";
	form.submit();
}