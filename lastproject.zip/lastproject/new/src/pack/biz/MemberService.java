package pack.biz;

import pack.beans.Member;
import pack.dao.MemberDao;

public class MemberService {
	MemberDao dao =new MemberDao();
	public void insertMember(Member m) {
		dao.insertMember(m);
		
	}

}
