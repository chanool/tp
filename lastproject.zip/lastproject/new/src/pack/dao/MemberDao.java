package pack.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import pack.beans.Member;

public class MemberDao {

	public Connection getConnection() {
		Connection con =null;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/copcroom?serverTimezone=UTC","root","cs1234");
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}

	public void insertMember(Member m)
	{
		try
		{
		Connection con = this.getConnection();
		PreparedStatement pstmt = con.prepareStatement("insert into member values(?,?,?,?)");
		pstmt.setString(1, m.getId());
		pstmt.setString(2, m.getPassword());
		pstmt.setString(3, m.getName());
		pstmt.setString(4, m.getMail());
		
		pstmt.executeUpdate();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	
	}

}
