package pack.member;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.sql.DataSource;

public class MemberMgr {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	private DataSource ds;

public MemberMgr() {
	Connection con =null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/copcroom?serverTimezone=UTC","root","cs1234");
		
	} catch (Exception e) {
		System.out.println("BoardMgr err : " + e);
	}
}


public boolean checkId(String id) {
	boolean b = false;
	try {
		String sql = "select id from member where id=?";
		conn =ds.getConnection();
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs = pstmt.executeQuery();
		b = rs.next();	
	} catch (Exception e) {
		System.out.println("checkId err" + e);
	}finally {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		} catch (Exception e2) {
		}	
	}
	return b;
}

public boolean memInsert(MemberBean bean) {
	boolean b = false;
	try {
		conn = ds.getConnection();
		String sql = "insert into member values(?,?,?,?)";
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, bean.getId());
		pstmt.setString(2, bean.getPasswd());
		pstmt.setString(3, bean.getname());
		pstmt.setString(4, bean.getEmail());
		if(pstmt.executeUpdate() > 0) b = true;
		
	} catch (Exception e) {
	}finally {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		} catch (Exception e2) {
		}	
	}
	return b;
}

public boolean loginCheck(String id, String passwd) {
	boolean b = false;
	try {
		conn = ds.getConnection();
		String sql = "select * from member where id=? and passwd=?";
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, passwd);
		rs = pstmt.executeQuery();
		b = rs.next();
	} catch (Exception e) {
	}finally {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		} catch (Exception e2) {
		}	
	}
	return b;
}

public MemberBean getMember(String id) {
	MemberBean bean = null;
	try {
		conn = ds.getConnection();
		String sql = "select * from member where id=?";
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs = pstmt.executeQuery();
		if(rs.next()) {
			bean = new MemberBean();
			bean.setId(rs.getString("id"));
			bean.setPasswd(rs.getString("passwd"));
			bean.setname(rs.getString("name"));
			bean.setEmail(rs.getString("email"));
		
		}
		
	} catch (Exception e) {
		System.out.println("getMember err: " + e);
	}finally {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		} catch (Exception e2) {
		}	
	}
	return bean;
}

public boolean memberUpdate(MemberBean bean, String id) {
	boolean b = false;
	try {
		conn = ds.getConnection();
		String sql = "update member set passwd=?, name=?, email=?";
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, bean.getPasswd());
		pstmt.setString(2, bean.getname());
		pstmt.setString(3, bean.getEmail());
		pstmt.setString(4, id);
		if(pstmt.executeUpdate() > 0) b = true;

	} catch (Exception e) {
		System.out.println("memeberUpdate err : " + e);
	}finally {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		} catch (Exception e2) {
		}	
	}
	return b;
}

public ArrayList<MemberBean> getMemberAll() {
	ArrayList<MemberBean> list = new ArrayList<>();
	try {
		conn = ds.getConnection();
		String sql = "select * from member";
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			MemberBean bean = new MemberBean();
			bean.setId(rs.getString("id"));
			bean.setname(rs.getString("name"));
			bean.setEmail(rs.getString("email"));
			list.add(bean);	
		}
	} catch (Exception e) {
		System.out.println("getMemberAll err:" + e);
	}finally {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
		} catch (Exception e2) {
		}	
	}
	return list;
}


}