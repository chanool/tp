package test;

public class Account {
	String id;
	String password;
	int money;
	public static int count =0;
	

	public Account(String id,String password) {
		this.id=id;
		this.password=password;
		this.money=0;
		this.count++;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	
	public void deposit(int money) {
		this.money +=money;
	}
	public boolean withdraw(int money) {
		if(this.money < money)
			return false;
		this.money -=money;
		return true;
	}
	public int query() {
		return this.money;
	}
	
	
}