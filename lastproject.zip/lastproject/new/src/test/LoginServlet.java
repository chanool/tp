package test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet{
	ServletContext sc;
	String adminID, adminPasswd;
	public void init(ServletConfig config) {
		sc = config.getServletContext();
		adminID = sc.getInitParameter("adminID");
		adminPasswd = sc.getInitParameter("adminPWD");
		
	}

	public void doGet(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
		String id= req.getParameter("id");
		String pwd=req.getParameter("passwd");
		
		PrintWriter out =resp.getWriter();
		
		Account[] accounts=(Account[])sc.getAttribute("accountList");
		if(id.equals(adminID) && pwd.equals(adminPasswd))
		{
			RequestDispatcher rd =req.getRequestDispatcher("adminMain.jsp");
			rd.forward(req, resp);
			return;
		}
		else if(accounts != null)
		{
			for(int i=0; i<Account.count; i++) {
				if(accounts[i].getId().equals(id) && accounts[i].getPassword().equals(pwd));
				HttpSession session =req.getSession();
				session.setAttribute("loginId", id);
				RequestDispatcher rd =req.getRequestDispatcher("main.jsp");
				rd.forward(req, resp);
				return;
			}
		}
		RequestDispatcher rd =req.getRequestDispatcher("index.jsp");
		rd.forward(req, resp);
		return;
	
	}

}
