package test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet{
	ServletContext sc;
	Account[] accounts;
	public void init(ServletConfig config) {
		sc = config.getServletContext();
		accounts = new Account[10];
		sc.setAttribute("accountList", accounts);
		
	}

	public void doGet(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
		String id= req.getParameter("id");
		String pwd=req.getParameter("passwd");
		
		PrintWriter out =resp.getWriter();
		Account newAccount = new Account(id,pwd);
		accounts[Account.count-1]= newAccount;
		
		RequestDispatcher rd =req.getRequestDispatcher("adminMain.jsp");
		rd.forward(req, resp);
		return;
	
	
	}
}