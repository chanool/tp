package test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class WithdrawServlet extends HttpServlet{
	ServletContext sc;
	
	public void init(ServletConfig config) {
		sc = config.getServletContext();

	}

	public void doGet(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
		int money= Integer.parseInt(req.getParameter("money"));
		PrintWriter out =resp.getWriter();
		
		Account[] accounts=(Account[])sc.getAttribute("accountList");
	
		HttpSession session=req.getSession();
		String id=(String)session.getAttribute("loginId");
		
		for(int i =0; i<Account.count;i++)
		{
			if(accounts[i].getId().equals(id))
			{
				accounts[i].withdraw(money);
				req.setAttribute("id", id);
				req.setAttribute("money", money);
				RequestDispatcher rd =req.getRequestDispatcher("withdrawOutput.jsp");
				rd.forward(req, resp);
				return;
			}
		}	
	}
}
